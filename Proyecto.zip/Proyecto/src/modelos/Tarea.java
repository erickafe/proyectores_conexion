/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelos;

/**
 *
 * @author Fernando
 */
public class Tarea {

    private final Integer id_tarea;
    private String titulo;
    private String descripcion;
    private String encargado;
    private String nivel_de_prioridad;
    private String proyector;
    private String fecha;

    public Tarea() {
        this.id_tarea = null;
        this.titulo = null;
        this.descripcion = null;
        this.encargado = null;
        this.nivel_de_prioridad = null;
        this.proyector = null;
        this.fecha = null;
    }

    public Tarea(Integer id_tarea, String titulo, String descripcion, String encargado, String nivel_de_prioridad, String proyector, String fecha) {
        this.id_tarea = id_tarea;
        this.titulo = titulo;
        this.descripcion = descripcion;
        this.encargado = encargado;
        this.nivel_de_prioridad = nivel_de_prioridad;
        this.proyector = proyector;
        this.fecha = fecha;
    }

    public Integer getId_tarea() {
        return id_tarea;
    }

    public String getTitulo() {
        return titulo;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public String getEncargado() {
        return encargado;
    }

    public String getNivel_de_prioridad() {
        return nivel_de_prioridad;
    }

    public String getProyector() {
        return proyector;
    }

    public String getFecha() {
        return fecha;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public void setEncargado(String encargado) {
        this.encargado = encargado;
    }

    public void setNivel_de_prioridad(String nivel_de_prioridad) {
        this.nivel_de_prioridad = nivel_de_prioridad;
    }

    public void setProyector(String proyector) {
        this.proyector = proyector;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    @Override
    public String toString() {
        return "Tarea{" + "id_tarea=" + id_tarea + ", titulo=" + titulo + ", descripcion=" + descripcion + ", encargado=" + encargado + ", nivel_de_prioridad=" + nivel_de_prioridad + ", proyector=" + proyector + ", fecha=" + fecha + '}';
    }

}
